<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'redcap' );

/** MySQL database username */
define( 'DB_USER', 'redcap' );

/** MySQL database password */
define( 'DB_PASSWORD', 'redcap' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '~X~!N6^;f7D]1W0~(|l=}`BV|Khz5EZa#m/nT&zk8bp~43^)T]sJuGX:r[_2zC|z');
define('SECURE_AUTH_KEY',  'X fPfFV7=(cii5o 4a$3:BISSH=|fqVmZ*]j(sX?)Nxu/QP!zf`<B,a[4=sq-_3/');
define('LOGGED_IN_KEY',    '%41-t;SP0Ln1wkbz2B-+m]|hZfqOjghIw(x c&(a`yTV+R-;D0FKQC2}.,Ne^h:y');
define('NONCE_KEY',        '>ela,+npWO?8sA@s6~+$s)@lX-ZfQ;y=+1F%2WGT`E9a1&6e#Ll{?[$$e9D-F^b?');
define('AUTH_SALT',        '!(j*Oy0(`iBqQrc`/s%T7g>@6KKp{Z&`DtJTg-Z`ddPx^CDy|8h0$+xL?N=;+ujz');
define('SECURE_AUTH_SALT', 'v0<Gbg,j+,+e:h$ uGlKbu|Kz+LE^@S4`>c&2?gNx<`<ZJn||HM:>$4H=o^E5L[,');
define('LOGGED_IN_SALT',   '+0L-1jJC?z~qmB3ZsN;+u<4O|jeY^}/N4a(Mlpe`;HT+E-O<SGF-N2NKrh8J^t:`');
define('NONCE_SALT',       '/`KekE--Oi(+KTGzP^S2r|8+Rp5}WcWV__S<LQ^AthVHXOqr,%qu8-HhznHoo`5/');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
